#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mode="${1:-help}"
if (( $# )); then shift; fi
case "$mode" in
  inspect) exec "${PEG_PYTHON:-python}" tools/peg_grasp_v2/inspect_mesh.py "$@" ;;
  tests) exec "${PEG_PYTHON:-python}" tools/peg_grasp_v2/test_cpu.py "$@" ;;
  probe) exec "${PEG_PYTHON:-python}" -u tools/peg_grasp_v2/probe.py "$@" ;;
  *) printf '%s\n' 'Usage: bash peg_grasp_v2.sh {inspect|tests|probe} [options]' ;;
esac
