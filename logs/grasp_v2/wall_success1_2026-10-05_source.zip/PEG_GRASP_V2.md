# Grasp v2: prima contatti realistici, poi apprendimento

La v1 ha completato L5 → R2 in 100/100 episodi con **presa assistita**. Rimane riproducibile con `bash peg_checkpoint1.sh play`.

Per la v2 ho esaminato la mesh USD del peg e i collider delle due dita. Il peg è un triangolo arrotondato di circa **16,8 × 18,6 × 17,2 mm**, alla scala attuale. Il foro ha un contorno sagomato. Il collider v1 usava invece un rettangolo esterno e un foro circolare: questo cambiava le superfici realmente toccate dalla pinza.

![Sezione del peg e zone di presa](docs/images/peg_grasp_v2_geometry.png)

La nuova prova mantiene la mesh visiva e costruisce collider che seguono triangolo, foro e bordi arrotondati. Lo scarto radiale massimo **nei punti campionati** è 0,077 mm. È ancora un'approssimazione, composta da 672 celle convesse.

Sono disponibili due prese:

- **Vertice:** arrivo laterale, ganasce sui due lati del vertice. Si possono provare tre vertici e altezze diverse. Il giunto delle dita resta fuori dal triangolo.
- **Parete dall'alto:** un dito dentro il foro e uno fuori. La penetrazione iniziale è 1 mm sotto il bordo superiore. L'apertura è più piccola, per lasciare spazio al piolo della board.

Le pose iniziali perfettamente verticali/orizzontali hanno portato il polso al limite di yaw di ±30°. Ora la parete viene approcciata con la pinza inclinata di **20° dalla verticale**; il vertice con un ingresso di **30° sopra l'orizzontale**. Per PSM1 la direzione di chiusura è inclinata di altri 30° attorno all'asse della pinza. PSM2 usa la parete superiore destra; PSM1 quella sinistra. La figura mostra le zone di presa, mentre il controller usa queste orientazioni oblique.

Prima di avviare Isaac, il comando verifica l'arrivo delle dita e **72 punti del percorso**, includendo approccio, lift, abbassamento e ritirata. La cinematica usa i veri frame dei giunti USD, verificati contro le pose delle ultime tracce Isaac. I limiti restano quelli originali, con 2° di margine sui giunti rotativi e 1 mm sull'inserzione. Una scelta di vertice/altezza non compatibile viene rifiutata subito. Questo controllo non certifica collisioni lungo tutto il percorso o tenuta fisica: quelle richiedono la simulazione.

Il controllo comanda soltanto giunti e ganasce. Il peg viene mosso dai contatti fisici: non viene agganciato alla pinza né riposizionato durante il movimento. Ogni dito ha un sensore di contatto filtrato sul peg; toccare la board o il piolo non vale come presa.

**Limite attuale:** il corpo resta rigido, con contatti elastici e attrito. La mesh non si schiaccia come gomma. È il primo esperimento fisico della v2; per una deformazione volumetrica serviranno un modello deformabile e misure del materiale reale. I collider delle dita sono quelli del robot USD, anch'essi da confrontare con le pinze reali. Nessun risultato sim-to-real è verificato.

## Comandi

Con `conda activate PegTransfer`, dalla cartella del progetto:

```bash
bash peg_grasp_v2.sh tests
```

Prima prova sul desktop della workstation, con GUI e velocità reale:

```bash
bash peg_grasp_v2.sh probe --mode vertex --height 0.5 --episodes 1 --realtime
```

Poi la presa sulla parete:

```bash
bash peg_grasp_v2.sh probe --mode wall --episodes 1 --realtime
```

Il controllo segue ora una **traiettoria di posa assoluta**: riferimento a 25 mm/s nello spazio libero, 5 mm/s vicino al peg e durante l’abbassamento, **3 mm/s durante il lift**, rotazione fino a 1 rad/s nello spazio libero. Le velocità effettive dipendono dai giunti e dai contatti. Il riferimento può precedere la pinza soltanto di 3 mm nello spazio libero e 0,5 mm vicino al peg. Nella presa sulla parete la pinza resta sul ramo di orientamento senza il precedente giro di 180°; lo scambio fra dito interno ed esterno conserva la geometria campionata della presa.

Ogni fase ha un massimo di **6000 passi = 60 secondi simulati** a 100 Hz. Quando raggiunge il target, passa subito alla fase successiva; la tenuta richiesta resta di 2 secondi consecutivi. Se l'errore di posa non migliora per 5 secondi simulati, interrompe con `*_motion_stalled`, senza aspettare inutilmente tutto il budget. `--stage_steps` cambia il massimo per fase, non la velocità. `--free_speed`, `--contact_speed` (m/s) e `--rotation_speed` (rad/s) regolano il riferimento. `--lift_speed` (m/s) regola separatamente il sollevamento.

Il terminale mostra ogni secondo simulato **`phase_error`** (distanza dal waypoint della fase), **`grasp_distance`** (distanza dal punto di presa sul peg), **`rotation_error`** e i giunti vicini al limite. In `above`, un errore di fase quasi nullo può ancora significare che la pinza è circa 29 mm sopra il punto di presa: non è un successo di grasp. La soglia di arrivo resta 0,7 mm e 0,05 rad; non è stata allargata per nascondere un blocco.

La GUI viene aggiornata a 25 Hz, mantenendo fisica a 400 Hz e controllo a 100 Hz. `--realtime` aggiunge attese solo se il calcolo è più veloce del tempo simulato; non accelera una workstation che impiega più tempo a calcolare i passi.

Da SSH, prova senza finestra e con tre ripetizioni:

```bash
bash peg_grasp_v2.sh probe --mode vertex --height 0.5 --episodes 3 --headless
```

Senza `--vertex`, PSM1 prova il vertice 2 sul lato verso la propria base, PSM2 il vertice 0. `--vertex 0`, `--vertex 1` e `--vertex 2` permettono una scelta esplicita, che resta da verificare rispetto ai limiti del polso. `--height 0.2` e `--height 0.8` cambiano l'altezza della presa laterale. `--arm 2` permette di provare la seconda pinza sullo stesso peg L5. Non è ancora una prova di handover né una policy appresa.

Report e tracce sono in **`logs/grasp_v2/`**, con nomi diversi a ogni esecuzione. Un fallimento termina con un codice diverso da zero e viene conservato nel report. Il motivo distingue contatto insufficiente, mancato raggiungimento della posa, perdita della presa e forza eccessiva.

`bash peg_grasp_v2.sh inspect` rigenera la figura e il profilo a partire dagli USD locali, senza avviare Isaac Sim. La prova controlla gli hash di peg e robot prima di partire. Se il robot non è nella cache originale, passare lo stesso file locale sia a `inspect --robot_usd FILE` sia a `probe --robot_usd FILE`.

## Cosa conta come successo

La prova deve arrivare con la pinza aperta, chiudere con contatti su **entrambe** le dita, sollevare il peg di 35 mm e mantenerlo per 2 secondi. Il peg deve superare l'altezza dei pioli, restare quasi fermo e non scivolare rispetto alla pinza. Per la presa sulla parete viene richiesta anche la distinzione fra contatto interno ed esterno; sui vertici entrambi devono essere esterni. Infine il controllo abbassa il peg, apre e si ritira.

Nel report, `physical_grasp_hold_success` indica quante prove hanno superato il lift e la tenuta; `cases[].complete` comprende anche abbassamento, rilascio e ritirata. `complete` al livello principale indica che la raccolta dei risultati è terminata, anche quando le prove sono fallite. La tenuta non basta a certificare un trasferimento completo.

## Parametri iniziali, da calibrare

| Parametro | Valore |
|---|---:|
| Massa peg | 5 g |
| Attrito statico e dinamico di peg e dita | 0,9 |
| Rigidezza del contatto normale | 1000 N/m |
| Smorzamento del contatto | 0,5 N·s/m |
| Coppia massima per ganascia | 0,015 N·m |
| Rigidezza / smorzamento del drive delle dita | 0,6 N·m/rad / 0,02 N·m·s/rad |
| Forza normale cercata per dito | 0,35 N, banda ±0,05 N |
| Pressione stabile prima del lift | 0,4 s |
| Interruzione per forza normale | oltre 1 N su un dito |
| Physics / controllo | 400 Hz / 100 Hz |
| GUI | 25 Hz |
| Riferimento in spazio libero / vicino al peg / lift | 25 / 5 / 3 mm/s |
| Riferimento angolare in spazio libero / vicino al peg | 1 / 0,2 rad/s |
| Limiti simulati giunti rotativi / inserzione | 1,5 rad/s / 0,04 m/s |

Questi valori sono **ipotesi iniziali**, non misure della gomma reale. Il sensore riporta le forze normali; non misura qui la forza tangenziale totale. La rigidezza è una proprietà del contatto e non equivale al modulo elastico della gomma. I [contatti elastici di PhysX](https://nvidia-omniverse.github.io/PhysX/physx/5.5.1/docs/RigidBodyDynamics.html) usano una molla e uno smorzatore; la [deformazione volumetrica](https://docs.omniverse.nvidia.com/kit/docs/omni_physics/108.1/dev_guide/deformables/deformable_bodies.html) richiede un modello diverso.

## Correzione dello scivolamento — 5 ottobre 2026

Le ultime tracce confermano che le pose oblique raggiungono il peg. Sulla parete il vecchio controllo iniziava il lift con circa 0,14–0,17 N sulle dita e perdeva i contatti entro circa 0,4 s. Sul vertice chiudeva fino a zero senza ottenere una pressione stabile su entrambe le dita; il peg si spostava rispetto alla pinza. Nelle tracce disponibili il fondo del peg resta vicino alla board: **la tenuta fisica non è ancora verificata**.

La nuova prova cerca **0,35 N su ciascun dito per almeno 0,4 s**, con contatti opposti nelle zone corrette e posizione del peg stabile rispetto alla pinza. Solo allora parte il lift. La coppia disponibile e la rigidezza del drive delle dita sono aumentate; la chiusura rallenta quando compare il contatto. Un dito più carico non fa aprire la pinza se l’altro ha ancora poca pressione.

Il lift parte verticalmente dalla posa realmente raggiunta, senza correggere lateralmente la pinza mentre stringe. Se la pressione cala, il movimento si ferma mentre le dita provano a recuperarla. La prova termina se i contatti mancano per 0,4 s, la pressione non torna entro 1 s, il peg scivola di 1,5 mm o ruota di 0,15 rad rispetto alla presa. Con dita chiuse senza pressione sufficiente termina dopo 1 s, invece di aspettare 60 s. Il successo richiede il lift completo di 35 mm e 2 s di tenuta.

L’attrito iniziale passa da 0,6 a **0,9**, un’ipotesi da calibrare, non un valore misurato della gomma. Il materiale delle dita e del peg viene assegnato **prima** dell’avvio della fisica, includendo il collider originale disabilitato del peg. Dopo l’avvio, il codice legge il buffer PhysX del peg: se l’attrito differisce, assegna i coefficienti tramite l’API dei materiali usata da Isaac Lab, senza cambiare la colonna della restituzione. Poi verifica di nuovo peg e quattro dita; se i valori non sono corretti interrompe la prova con i coefficienti effettivi nel messaggio. Questo evita di confondere il materiale scritto negli USD con quello effettivamente usato dal simulatore.

I log mostrano `force_N`, `paused` e `slip_mm`. Il report conserva i valori dell’attrito effettivo in `actual_physx_materials`. `grip_control` nella traccia contiene la decisione del controller presa prima del passo; forze e posa della stessa riga sono misurate dopo il passo. La capacità d’attrito stimata è soltanto un controllo preliminare sul peso: non certifica la tenuta dei contatti inclinati sui vertici.

Per confrontare l’attrito precedente mantenendo il nuovo controllo:

```bash
bash peg_grasp_v2.sh probe --mode wall --episodes 1 --friction 0.6 --realtime
bash peg_grasp_v2.sh probe --mode vertex --episodes 1 --friction 0.6 --realtime
```

**Stato:** 32 test CPU superati, compresi i campioni delle prese fallite, la pressione stabile, il recupero della presa, l’interruzione per scivolamento e la verifica dei materiali. Nessuna nuova simulazione o policy appresa eseguita per questa modifica. Prima verifichiamo la presa con i comandi standard sopra; poi procediamo a handover, dimostrazioni e training. La randomizzazione delle posizioni verrà dopo questa verifica.

## Arresto all’avvio durante la verifica dell’attrito

Le prove dell’utente delle 14:24–14:26 si sono interrotte con `Peg actual friction differs from requested friction`, prima della fase `settle`: i PSM non avevano ancora ricevuto comandi di movimento. Questi report contengono zero episodi e non misurano una presa.

Corretto il materiale di tutti i collider del peg e aggiunta l’assegnazione nel buffer PhysX quando necessaria, seguita dalla verifica. Il report distingue `initial_physx_materials` dai coefficienti finali `actual_physx_materials`. La GUI viene chiusa anche se questa inizializzazione fallisce. All’avvio deve comparire `PhysX friction verified on peg and four fingers`, poi il log delle fasi `settle` e `above`.

**Verificato:** 34 test CPU, inclusa una simulazione del buffer materiali con valori misti e un avvio simulato che fallisce e chiude ambiente/applicazione. Questi test non avviano Isaac Sim. L’esito della correzione sulla workstation resta da verificare con il normale comando `probe`.
